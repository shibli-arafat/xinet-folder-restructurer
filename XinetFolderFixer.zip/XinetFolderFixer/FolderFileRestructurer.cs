﻿using System;
using System.Collections.Specialized;
using System.IO;

namespace XinetFolderFixer
{
    public class FolderFileRestructurer
    {
        private StringCollection _CharactersToReplace;
        private ExcelDataReader _ExcelFileHandler;

        public FolderFileRestructurer(ExcelDataReader excelFileHandler, StringCollection charactersToReplace)
        {
            _ExcelFileHandler = excelFileHandler;
            _CharactersToReplace = charactersToReplace;
        }

        public void RestructureFoldersAndFiles()
        {
            Console.WriteLine("---The tool started---");
            Console.WriteLine("Reading data from excel file...");
            ExcelDataCollection dataCollection = _ExcelFileHandler.ReadData();
            foreach (ExcelData data in dataCollection)
            {
                Console.WriteLine("Creating folder {0}", data.OutputPath);
                //Creating output folder
                CreateFolder(data.OutputPath);
                Console.WriteLine("Moving files from folder {0} to folder {1}", data.InputPath, data.OutputPath);
                //Moving the files from input folder to the output folder with sanitizing the file name
                RenameFilesAndMove(data.InputPath, data.OutputPath);
            }
            Console.WriteLine("---The tool ended---");
        }

        public void CreateFolder(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }            
        }

        private void RenameFilesAndMove(string fromFolder, string toFolder)
        {
            if (!Directory.Exists(fromFolder))
            {
                Console.WriteLine("Directory {0} doesn't exist", fromFolder);
                return;
            }
            DirectoryInfo dirInfo = new DirectoryInfo(fromFolder);
            foreach (FileInfo fileInfo in dirInfo.GetFiles())
            {
                string destFileName = Path.Combine(toFolder, RenameFile(fileInfo.Name));
                if (!File.Exists(destFileName))
                {
                    fileInfo.MoveTo(destFileName);
                }
            }
        }

        public string RenameFile(string fileName)
        {
            string newName = Path.GetFileNameWithoutExtension(fileName);
            foreach (string character in _CharactersToReplace)
            {
                newName = newName.Replace(character, "-");
            }
            newName = newName.TrimEnd('-');
            newName = string.Format("{0}{1}", newName, Path.GetExtension(fileName));
            return newName;
        }
    }
}
